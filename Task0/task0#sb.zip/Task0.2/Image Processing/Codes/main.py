import cv2
import numpy as np
import os

def partA():
    pass

def partB():
    pass

def partC():
    pass

def partD():
    pass

partA()
partB()
partC()
partD()